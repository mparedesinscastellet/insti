# CHANGES MADE
1. First, I downloaded and opened the project.
2. When I opened it, I started to change and solve the problems with the extension help.
3. Then, I changed the name Ernest to my name, Martina, in the index.html.
4. In the JS file, I used the rename function to change the variable "i" to "count".
5. I changed the background color in the .css file.
6. I added a JS file to add a function that says "Goodbye" after 10 seconds.
7. I change settings...
8. And finally, I created a .md file for explaining the task.

It was difficult, because I don't know a lot about JS, but well.
