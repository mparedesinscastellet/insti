function DecirAdios(){
    console.log('Goodbye');
}

setTimeout(DecirAdios, 10000);